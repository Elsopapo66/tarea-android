package com.example.calculadorajesusvidal;



import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import java.util.ArrayList;

public class ResultadosActivity extends AppCompatActivity {

    ListView listViewResultados;
    ArrayList<String> historial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);

        listViewResultados = findViewById(R.id.listViewResultados);

        // Obtener el historial pasado desde MainActivity
        historial = getIntent().getStringArrayListExtra("historial");

        // Mostrar los resultados en el ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, historial);
        listViewResultados.setAdapter(adapter);
    }
}

