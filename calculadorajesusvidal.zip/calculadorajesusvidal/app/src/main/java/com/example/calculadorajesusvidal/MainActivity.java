package com.example.calculadorajesusvidal;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    TextView txtResultado, txtMensajeResultado;
    ArrayList<String> historialResultados = new ArrayList<>();
    double resultadoActual = 0;
    String operacionActual = "";
    boolean nuevaOperacion = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtResultado = findViewById(R.id.txtResultado);
        txtMensajeResultado = findViewById(R.id.txtMensajeResultado);
        Button btnHistorial = findViewById(R.id.btnHistorial);

        btnHistorial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ResultadosActivity.class);
                intent.putStringArrayListExtra("historial", historialResultados);
                startActivity(intent);
            }
        });
    }

    // Maneja los números (se activa al presionar los botones de números)
    public void clickNumero(View view) {
        String valor = ((Button) view).getText().toString();
        String valorActual = txtResultado.getText().toString();

        if (valorActual.equals("0")) {
            txtResultado.setText(valor);
        } else {
            txtResultado.setText(valorActual + valor);
        }
    }

    // Maneja las operaciones (se activa al presionar los botones de operadores)
    public void procesarOperacion(View view) {
        String operacion = ((Button) view).getText().toString();
        double valorActual = Double.parseDouble(txtResultado.getText().toString());

        if (nuevaOperacion) {
            resultadoActual = valorActual;
            nuevaOperacion = false;
        } else {
            realizarOperacion(valorActual);
        }

        if (operacion.equals("=")) {
            mostrarResultado(resultadoActual);
            operacionActual = ""; // Reinicia la operación, pero mantiene el resultado
        } else {
            operacionActual = operacion;
            txtResultado.setText("0"); // Reinicia el display para la siguiente entrada
        }
    }

    // Realiza la operación actual
    public void realizarOperacion(double valorActual) {
        switch (operacionActual) {
            case "+":
                resultadoActual += valorActual;
                break;
            case "-":
                resultadoActual -= valorActual;
                break;
            case "*":
                resultadoActual *= valorActual;
                break;
            case "/":
                resultadoActual /= valorActual;
                break;
        }
    }

    // Muestra el resultado en la pantalla y en el mensaje
    public void mostrarResultado(double resultado) {
        if (resultado == (long) resultado) {
            txtResultado.setText(String.format("%d", (long) resultado));
            txtMensajeResultado.setText("Resultado: " + String.format("%d", (long) resultado));
        } else {
            txtResultado.setText(String.format("%s", resultado));
            txtMensajeResultado.setText("Resultado: " + String.format("%s", resultado));
        }

        txtMensajeResultado.setVisibility(View.VISIBLE);
        guardarResultado(resultado);
    }

    // Guarda el resultado en el historial
    public void guardarResultado(double resultado) {
        if (resultado == (long) resultado) {
            historialResultados.add(String.format("%d", (long) resultado));
        } else {
            historialResultados.add(String.format("%s", resultado));
        }
    }
}


